import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactListComponent } from './contacts/contact-list/contact-list.component';
import { ContactsComponent } from './contacts/contacts.component';
import { FavComponent } from './fav/fav.component';
import { EmergencyComponent } from './emergency/emergency.component';
import { ContactDetailComponent } from './contacts/contact-detail/contact-detail.component';
import { EditComponent } from './contacts/edit/edit.component';


const routes: Routes = [
  {path:'contact-detail',component :ContactDetailComponent},
  // {path:'edit',component :EditComponent},


  {path:'contact-list',component :ContactListComponent,children:[
    //  {path:'',component:ContactListComponent},
     {path:'new',component:EditComponent},
     {path:':id',redirectTo:'/contact-list'},
     {path:':id/edit',component:ContactDetailComponent},

  ]},
  {path:'fav',component :FavComponent},
  {path:'emergency',component :EmergencyComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
// redirectTo:'/contacts',pathMatch:'full'