import { contact } from './contact.model';
import { EventEmitter } from '@angular/core';
// import { Subject } from 'rxjs/internal/Subject';
import { Subject } from 'rxjs';

export class ContactService{
     contactsChanged =new Subject<contact[]>();
    contactSelected=new EventEmitter<contact>();
   private contacts:contact[]=[
        new contact('Rythem',1234,'r@gmail.com ','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQlyqYZmqQ5nx9BfD5tIRWbqnl6yBd6K2atpwoQBtZaPCjX-pUp'),
        new contact('Mayank',1234,'r@gmail.com ','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR3lWZMyBMLRIQSTZNCcD5_jGKu04H4prZQhUqMFJnV2LXD4s4-'),
        new contact('Sakshi',1234,'r@gmail.com ','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQlyqYZmqQ5nx9BfD5tIRWbqnl6yBd6K2atpwoQBtZaPCjX-pUp'),
        new contact('Himanshu',1234,'r@gmail.com ','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR3lWZMyBMLRIQSTZNCcD5_jGKu04H4prZQhUqMFJnV2LXD4s4-'),
     
      ];
//  private recipes: recipe[]=[];

 getContacts(){
      return this.contacts.slice();
 }
 getContact(id:number){
    return this.contacts[id];
 }
 addContact(con:contact){
      this.contacts.push(con);
      this.contactsChanged.next(this.contacts.slice());
 }
 updatecontact(){}

 }