export class posts{
    name: string; 
    ContactNumber: number;
     Email:string ; 
     Image:string;
     id?: string;
}