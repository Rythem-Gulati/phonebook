export class contact{
    public name: string;
    public cnumber:number;
    public email:string;
    public image:string;
    

    constructor( name:string,cnumber:number,email:string,image:string){
       this.name=name;
       this.cnumber=cnumber;
       this.email=email;
       this.image=image;
    }
}